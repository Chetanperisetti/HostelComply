package my.hostelcomply.app.plumberPanel;

import androidx.fragment.app.Fragment;

public class PlumberSolvedComplaintFragment extends Fragment {
}
